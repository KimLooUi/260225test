
  # 报价系统原型设计

  This is a code bundle for 报价系统原型设计. The original project is available at https://www.figma.com/design/8F9xPzgZCK6SLIh85p3mI5/%E6%8A%A5%E4%BB%B7%E7%B3%BB%E7%BB%9F%E5%8E%9F%E5%9E%8B%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  