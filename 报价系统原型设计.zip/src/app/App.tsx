import { QuotationSystem } from './components/QuotationSystem';

export default function App() {
  return (
    <div className="size-full">
      <QuotationSystem />
    </div>
  );
}
