import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/app/components/ui/card';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/app/components/ui/collapsible';
import { Button } from '@/app/components/ui/button';
import { Separator } from '@/app/components/ui/separator';
import { Badge } from '@/app/components/ui/badge';
import { Slider } from '@/app/components/ui/slider';
import { Switch } from '@/app/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/app/components/ui/radio-group';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, 
  ChevronDown, 
  Info, 
  Settings2, 
  Package, 
  Box, 
  Check, 
  Percent, 
  Ruler, 
  ArrowRight,
  TrendingUp,
  Tag,
  CircleDollarSign,
  Factory,
  Search,
  Zap,
  Layers,
  FileText,
  Save,
  Printer,
  RotateCcw,
  Send,
  History,
  Clock,
  Calendar
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { toast } from 'sonner';

// 模拟标准刀具参考数据
const standardToolReferences = [
  {
    id: 1,
    name: '标准铣刀 HRC55',
    diameter: 6,
    length: 30,
    rCorner: 0.5,
    processingTime: 45,
    processingCost: 120,
    coating: 'TiAlN',
    material: '硬质合金',
  },
  {
    id: 2,
    name: '标准铣刀 HRC60',
    diameter: 8,
    length: 40,
    rCorner: 1.0,
    processingTime: 60,
    processingCost: 180,
    coating: 'AlCrN',
    material: '超硬合金',
  },
  {
    id: 3,
    name: '球头铣刀 R3',
    diameter: 6,
    length: 50,
    rCorner: 3.0,
    processingTime: 55,
    processingCost: 150,
    coating: 'TiSiN',
    material: '微粒钨钢',
  },
];

const COLORS = ['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981', '#ec4899'];

// 定义报价记录类型
interface QuoteRecord {
  id: string;
  timestamp: number;
  productName: string;
  productModel: string;
  bladeDiameter: string;
  bladeLength: string;
  rCorner: string;
  stepType: string;
  coatingParam: string;
  passivation: boolean;
  packaging: string;
  profitRate: number;
  discountRate: number;
  finalPrice: number;
  status: 'saved' | 'submitted';
}

export function QuotationSystem() {
  // 产品基本信息
  const [productName, setProductName] = useState('');
  const [productModel, setProductModel] = useState('');

  // 规格参数
  const [bladeDiameter, setBladeDiameter] = useState('');
  const [bladeLength, setBladeLength] = useState('');
  const [rCorner, setRCorner] = useState('');

  // 加工选项
  const [stepType, setStepType] = useState('默认');
  const [coatingParam, setCoatingParam] = useState('');
  const [passivation, setPassivation] = useState(false);
  const [packaging, setPackaging] = useState('标准包装');

  // 费用明细
  const [materialCost, setMaterialCost] = useState(0);
  const [cncCost, setCncCost] = useState(0);
  const [stepCost, setStepCost] = useState(0);
  const [passivationCost, setPassivationCost] = useState(0);
  const [packagingCost, setPackagingCost] = useState(0);

  // 利润率和折扣率
  const [profitRate, setProfitRate] = useState(20);
  const [discountRate, setDiscountRate] = useState(0);

  // 标准刀具参考展开状态
  const [referenceExpanded, setReferenceExpanded] = useState(false);

  // 历史记录
  const [history, setHistory] = useState<QuoteRecord[]>([]);

  // 计算总成本
  const totalCost = materialCost + cncCost + stepCost + passivationCost + packagingCost;

  // 计算加上利润后的价格
  const priceWithProfit = totalCost * (1 + profitRate / 100);

  // 计算最终报价（应用折扣）
  const finalQuotation = priceWithProfit * (1 - discountRate / 100);

  // Chart Data
  const costData = [
    { name: '材料', value: materialCost },
    { name: '数控', value: cncCost },
    { name: '段差', value: stepCost },
    { name: '钝化', value: passivationCost },
    { name: '包装', value: packagingCost },
  ].filter(item => item.value > 0);

  // 根据输入参数自动计算费用
  useEffect(() => {
    // 根据刃径和刃长计算材料费用
    if (bladeDiameter && bladeLength) {
      const diameter = parseFloat(bladeDiameter);
      const length = parseFloat(bladeLength);
      // 简单的模拟公式
      if (!isNaN(diameter) && !isNaN(length)) {
         setMaterialCost(diameter * length * 0.5 + 50);
      } else {
         setMaterialCost(0);
      }
    } else {
      setMaterialCost(0);
    }

    // 根据刃径和刃长计算数控加工费用
    if (bladeDiameter && bladeLength) {
      const diameter = parseFloat(bladeDiameter);
      const length = parseFloat(bladeLength);
       // 简单的模拟公式
      if (!isNaN(diameter) && !isNaN(length)) {
         setCncCost(diameter * length * 1.2 + 80);
      } else {
        setCncCost(0);
      }
    } else {
      setCncCost(0);
    }

    // 根据段差类型计算段差费用
    if (stepType === '大头') {
      setStepCost(30);
    } else if (stepType === '顶磨') {
      setStepCost(50);
    } else {
      setStepCost(0);
    }

    // 钝化费用
    setPassivationCost(passivation ? 20 : 0);

    // 包装费用
    if (packaging === '精装包装') {
      setPackagingCost(15);
    } else if (packaging === '出口包装') {
      setPackagingCost(25);
    } else {
      setPackagingCost(5);
    }
  }, [bladeDiameter, bladeLength, stepType, passivation, packaging]);

  const handleProfitChange = (value: number[]) => {
    setProfitRate(value[0]);
  };

  const handleDiscountChange = (value: number[]) => {
    setDiscountRate(value[0]);
  };

  // 重置表单
  const handleReset = () => {
    setProductName('');
    setProductModel('');
    setBladeDiameter('');
    setBladeLength('');
    setRCorner('');
    setStepType('默认');
    setCoatingParam('');
    setPassivation(false);
    setPackaging('标准包装');
    setProfitRate(20);
    setDiscountRate(0);
    toast.info("表单已重置");
  };

  // 保存报价
  const handleSave = () => {
    if (!productName) {
      toast.error("请输入产品名称");
      return;
    }
    const newRecord: QuoteRecord = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      productName,
      productModel,
      bladeDiameter,
      bladeLength,
      rCorner,
      stepType,
      coatingParam,
      passivation,
      packaging,
      profitRate,
      discountRate,
      finalPrice: finalQuotation,
      status: 'saved'
    };
    setHistory([newRecord, ...history]);
    toast.success("报价已保存到历史记录");
  };

  // 提交报价
  const handleSubmit = () => {
    if (!productName) {
      toast.error("请输入产品名称");
      return;
    }
    // 模拟提交过程
    const promise = new Promise((resolve) => setTimeout(resolve, 1000));
    toast.promise(promise, {
      loading: '正在提交报价...',
      success: () => {
        const newRecord: QuoteRecord = {
          id: Date.now().toString(),
          timestamp: Date.now(),
          productName,
          productModel,
          bladeDiameter,
          bladeLength,
          rCorner,
          stepType,
          coatingParam,
          passivation,
          packaging,
          profitRate,
          discountRate,
          finalPrice: finalQuotation,
          status: 'submitted'
        };
        setHistory([newRecord, ...history]);
        return '报价提交成功！';
      },
      error: '提交失败',
    });
  };

  // 打印报价单
  const handlePrint = () => {
    window.print();
  };

  // 加载历史记录
  const loadHistoryItem = (record: QuoteRecord) => {
    setProductName(record.productName);
    setProductModel(record.productModel);
    setBladeDiameter(record.bladeDiameter);
    setBladeLength(record.bladeLength);
    setRCorner(record.rCorner);
    setStepType(record.stepType);
    setCoatingParam(record.coatingParam);
    setPassivation(record.passivation);
    setPackaging(record.packaging);
    setProfitRate(record.profitRate);
    setDiscountRate(record.discountRate);
    toast.success(`已加载 "${record.productName}" 的报价记录`);
    
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50/50 font-sans text-slate-900 pb-20 selection:bg-blue-100 selection:text-blue-900 print:bg-white">
      {/* 顶部导航 - 打印时隐藏 */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 print:hidden">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-2 rounded-lg text-white shadow-lg shadow-blue-500/20">
              <Factory className="size-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-slate-900 leading-none">刀具加工报价系统</h1>
              <p className="text-[10px] uppercase tracking-wider text-slate-500 mt-0.5 font-medium">Precision Tooling Quotation</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-slate-500 hover:text-slate-900" onClick={handleReset}>
              <RotateCcw className="size-4 mr-2" />
              重置
            </Button>
            <Button size="sm" className="bg-slate-900 hover:bg-slate-800 shadow-md transition-all active:scale-95" onClick={handlePrint}>
              <Printer className="mr-2 size-4" /> 打印报价单
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          
          {/* 左侧：输入区域 (占 7 列) */}
          <div className="xl:col-span-7 space-y-6">
            
            {/* 1. 产品基本信息 & 规格参数 - 合并为两列布局 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.3 }}
                className="h-full"
              >
                <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow h-full flex flex-col">
                  <CardHeader className="pb-3 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center gap-2 text-slate-800">
                      <Box className="size-4 text-blue-500" />
                      <span className="font-semibold text-sm uppercase tracking-wide">基本信息</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-5 flex-1 space-y-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="productName" className="text-xs font-medium text-slate-500">产品名称</Label>
                      <div className="relative">
                        <Input
                          id="productName"
                          value={productName}
                          onChange={(e) => setProductName(e.target.value)}
                          placeholder="输入产品名称"
                          className="pl-9 h-10 border-slate-200 focus-visible:ring-blue-500 transition-all"
                        />
                        <Tag className="absolute left-3 top-2.5 size-4 text-slate-400" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="productModel" className="text-xs font-medium text-slate-500">产品型号</Label>
                      <div className="relative">
                        <Input
                          id="productModel"
                          value={productModel}
                          onChange={(e) => setProductModel(e.target.value)}
                          placeholder="输入型号代码"
                          className="pl-9 h-10 border-slate-200 focus-visible:ring-blue-500 transition-all"
                        />
                        <Layers className="absolute left-3 top-2.5 size-4 text-slate-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.3, delay: 0.05 }}
                className="h-full"
              >
                <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow h-full flex flex-col">
                   <CardHeader className="pb-3 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center gap-2 text-slate-800">
                      <Ruler className="size-4 text-indigo-500" />
                      <span className="font-semibold text-sm uppercase tracking-wide">规格参数</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-5 flex-1 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-slate-500">刃径 (mm)</Label>
                        <Input
                          type="number"
                          value={bladeDiameter}
                          onChange={(e) => setBladeDiameter(e.target.value)}
                          placeholder="6.0"
                          className="h-10 font-mono text-sm border-slate-200 focus-visible:ring-indigo-500"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-slate-500">刃长 (mm)</Label>
                        <Input
                          type="number"
                          value={bladeLength}
                          onChange={(e) => setBladeLength(e.target.value)}
                          placeholder="30.0"
                          className="h-10 font-mono text-sm border-slate-200 focus-visible:ring-indigo-500"
                        />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-slate-500">R角 (mm)</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={rCorner}
                          onChange={(e) => setRCorner(e.target.value)}
                          placeholder="0.5"
                          className="h-10 font-mono text-sm border-slate-200 focus-visible:ring-indigo-500"
                        />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* 2. 加工选项 */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-3 border-b border-slate-100 bg-slate-50/50">
                   <div className="flex items-center gap-2 text-slate-800">
                    <Settings2 className="size-4 text-amber-500" />
                    <span className="font-semibold text-sm uppercase tracking-wide">工艺配置</span>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  {/* 段差类型选择 */}
                  <div className="space-y-3">
                    <Label className="text-xs font-medium text-slate-500 uppercase tracking-wider">段差处理类型</Label>
                    <RadioGroup 
                      value={stepType} 
                      onValueChange={setStepType} 
                      className="grid grid-cols-1 sm:grid-cols-3 gap-3"
                    >
                      {['默认', '大头', '顶磨'].map((type) => (
                        <Label
                          key={type}
                          className={`
                            relative flex flex-col items-start p-3 cursor-pointer rounded-lg border transition-all duration-200
                            ${stepType === type 
                              ? 'border-amber-500 bg-amber-50 shadow-sm' 
                              : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'}
                          `}
                        >
                          <RadioGroupItem value={type} className="sr-only" />
                          <div className="flex items-center justify-between w-full mb-1">
                            <span className={`font-medium text-sm ${stepType === type ? 'text-amber-900' : 'text-slate-700'}`}>{type}</span>
                            {stepType === type && <div className="bg-amber-500 rounded-full p-0.5"><Check className="size-2.5 text-white" /></div>}
                          </div>
                          <span className="text-xs text-slate-500">
                            {type === '默认' ? '无特殊段差处理' : type === '大头' ? '头部加大处理 +¥30' : '顶部精磨处理 +¥50'}
                          </span>
                        </Label>
                      ))}
                    </RadioGroup>
                  </div>

                  <Separator className="bg-slate-100" />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <Label htmlFor="coatingParam" className="text-xs font-medium text-slate-500">涂层参数</Label>
                       <div className="relative">
                          <Input
                            id="coatingParam"
                            value={coatingParam}
                            onChange={(e) => setCoatingParam(e.target.value)}
                            placeholder="TiAlN, AlCrN..."
                            className="pl-9 h-10 border-slate-200 focus-visible:ring-amber-500"
                          />
                          <Zap className="absolute left-3 top-2.5 size-4 text-slate-400" />
                       </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="packaging" className="text-xs font-medium text-slate-500">包装规格</Label>
                      <Select value={packaging} onValueChange={setPackaging}>
                        <SelectTrigger id="packaging" className="h-10 border-slate-200 focus:ring-amber-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="标准包装">
                            <span className="flex items-center gap-2">
                              <Package className="size-4 text-slate-400" /> 标准包装
                            </span>
                          </SelectItem>
                          <SelectItem value="精装包装">
                            <span className="flex items-center gap-2">
                              <Package className="size-4 text-amber-500" /> 精装包装 (+¥15)
                            </span>
                          </SelectItem>
                          <SelectItem value="出口包装">
                            <span className="flex items-center gap-2">
                              <Package className="size-4 text-purple-500" /> 出口包装 (+¥25)
                            </span>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center justify-between bg-slate-50/50 p-4 rounded-lg border border-slate-100">
                    <div className="space-y-0.5">
                      <Label htmlFor="passivation-mode" className="text-sm font-medium text-slate-900 cursor-pointer">
                        钝化处理 (Passivation)
                      </Label>
                      <p className="text-xs text-slate-500">
                        增加刀具刃口强度，延长使用寿命 <span className="text-emerald-600 font-medium">+¥20</span>
                      </p>
                    </div>
                    <Switch
                      id="passivation-mode"
                      checked={passivation}
                      onCheckedChange={setPassivation}
                      className="data-[state=checked]:bg-emerald-500"
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* 3. 标准刀具参考信息 */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.3, delay: 0.15 }}
            >
              <Card className="border-slate-200 shadow-sm overflow-hidden bg-white">
                <Collapsible open={referenceExpanded} onOpenChange={setReferenceExpanded}>
                  <div className="w-full">
                    <CollapsibleTrigger asChild>
                       <div className="flex items-center justify-between p-4 bg-slate-50/50 hover:bg-slate-100/50 border-b border-slate-100 cursor-pointer transition-colors group">
                        <div className="flex items-center gap-2">
                          <div className="bg-sky-100 text-sky-600 p-1.5 rounded-md group-hover:bg-sky-200 transition-colors">
                            <Search className="size-4" />
                          </div>
                          <span className="font-semibold text-sm uppercase tracking-wide text-slate-800">标准刀具参考库</span>
                          {!referenceExpanded && (
                            <Badge variant="secondary" className="bg-slate-200 text-slate-600 ml-2 font-normal">
                              {standardToolReferences.length} items
                            </Badge>
                          )}
                        </div>
                        <ChevronDown className={`size-4 text-slate-400 transition-transform duration-300 ${referenceExpanded ? 'rotate-180' : ''}`} />
                      </div>
                    </CollapsibleTrigger>
                  
                    <CollapsibleContent>
                      <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto">
                        <div className="grid grid-cols-12 gap-2 px-6 py-2 bg-slate-50 text-xs font-medium text-slate-500 border-b border-slate-100">
                           <div className="col-span-4">名称</div>
                           <div className="col-span-2 text-center">规格</div>
                           <div className="col-span-2 text-center">材质</div>
                           <div className="col-span-2 text-right">工时</div>
                           <div className="col-span-2 text-right">参考价</div>
                        </div>
                        {standardToolReferences.map((ref) => (
                          <div key={ref.id} className="grid grid-cols-12 gap-2 px-6 py-3 items-center hover:bg-sky-50/30 transition-colors text-sm">
                            <div className="col-span-4 font-medium text-slate-700 truncate" title={ref.name}>{ref.name}</div>
                            <div className="col-span-2 text-center text-slate-500 text-xs">D{ref.diameter} × L{ref.length}</div>
                            <div className="col-span-2 text-center text-slate-500 text-xs truncate">{ref.material}</div>
                            <div className="col-span-2 text-right font-mono text-slate-600">{ref.processingTime}m</div>
                            <div className="col-span-2 text-right font-mono font-medium text-blue-600">¥{ref.processingCost}</div>
                          </div>
                        ))}
                        <div className="p-2 text-center text-xs text-slate-400 bg-slate-50">
                           数据仅供参考，实际报价以计算为准
                        </div>
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              </Card>
            </motion.div>
          </div>

          {/* 右侧：费用明细和报价 (占 5 列) */}
          <div className="xl:col-span-5 space-y-6 xl:sticky xl:top-24">
            
            {/* 费用明细与图表 */}
             <motion.div 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              transition={{ duration: 0.4 }}
            >
              <Card className="border-slate-200 shadow-md overflow-hidden bg-white">
                <CardHeader className="bg-slate-900 text-white py-4 px-6 border-b border-slate-800">
                  <div className="flex items-center justify-between">
                     <CardTitle className="text-base font-medium flex items-center gap-2">
                        <Calculator className="size-4 text-blue-400" />
                        费用估算分析
                      </CardTitle>
                      <Badge className="bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700">实时</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  {/* 可视化图表 */}
                  <div className="h-48 bg-slate-50 border-b border-slate-100 flex items-center justify-center py-4 print:hidden">
                    {totalCost > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={costData}
                            cx="50%"
                            cy="50%"
                            innerRadius={40}
                            outerRadius={65}
                            paddingAngle={2}
                            dataKey="value"
                          >
                            {costData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <RechartsTooltip 
                             contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                             itemStyle={{ fontSize: '12px', fontWeight: 600 }}
                          />
                          <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                       <div className="flex flex-col items-center justify-center text-slate-300">
                          <CircleDollarSign className="size-10 mb-2 opacity-20" />
                          <span className="text-xs">等待输入参数...</span>
                       </div>
                    )}
                  </div>

                  <div className="divide-y divide-slate-100/50">
                    {[
                      { label: '材料成本', value: materialCost, color: COLORS[0] },
                      { label: '数控加工', value: cncCost, color: COLORS[1] },
                      { label: '段差处理', value: stepCost, color: COLORS[2] },
                      { label: '钝化处理', value: passivationCost, color: COLORS[3] },
                      { label: '包装费用', value: packagingCost, color: COLORS[4] },
                    ].map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center px-6 py-2.5 hover:bg-slate-50 transition-colors group">
                        <span className="text-slate-500 text-sm flex items-center gap-2">
                          <span className="size-2 rounded-full" style={{ backgroundColor: item.color }}></span>
                          {item.label}
                        </span>
                        <span className={`font-mono transition-all ${item.value > 0 ? 'text-slate-900 font-medium' : 'text-slate-300'}`}>
                          ¥{item.value.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="px-6 py-4 bg-slate-50 flex justify-between items-center border-t border-slate-200">
                    <span className="font-semibold text-slate-600 text-sm uppercase tracking-wide">基础成本合计</span>
                    <span className="font-mono font-bold text-slate-800 text-lg">¥{totalCost.toFixed(2)}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* 利润与折扣控制 */}
             <motion.div 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              transition={{ duration: 0.4, delay: 0.1 }}
              className="print:hidden"
            >
              <Card className="border-slate-200 shadow-sm">
                 <CardContent className="pt-6 space-y-6">
                    {/* 利润率 */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
                           <TrendingUp className="size-4 text-emerald-500" /> 预期利润率
                        </Label>
                        <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 font-mono">
                           {profitRate}%
                        </Badge>
                      </div>
                      <Slider
                        value={[profitRate]}
                        onValueChange={handleProfitChange}
                        max={100}
                        step={1}
                        className="py-1"
                      />
                    </div>

                    <Separator className="bg-slate-100" />

                    {/* 折扣率 */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
                           <Percent className="size-4 text-rose-500" /> 客户折扣
                        </Label>
                        <Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-200 font-mono">
                           -{discountRate}%
                        </Badge>
                      </div>
                      <Slider
                        value={[discountRate]}
                        onValueChange={handleDiscountChange}
                        max={50}
                        step={1}
                        className="py-1"
                      />
                    </div>
                 </CardContent>
              </Card>
            </motion.div>

            {/* 最终报价 */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} 
              animate={{ opacity: 1, scale: 1 }} 
              transition={{ duration: 0.4, delay: 0.2 }}
            >
              <div className="relative group rounded-2xl">
                 <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
                <Card className="relative border-0 bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl overflow-hidden rounded-xl">
                  {/* 背景装饰 */}
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                     <Factory className="size-32" />
                  </div>

                  <CardContent className="p-8 text-center space-y-2 relative z-10">
                    <span className="text-blue-200 font-medium text-sm uppercase tracking-widest block mb-4">最终报价 (含税)</span>
                    <div className="flex items-center justify-center">
                       <span className="text-3xl font-light text-blue-400 mr-2">¥</span>
                       <AnimatePresence mode="popLayout">
                         <motion.span 
                            key={finalQuotation}
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -20, opacity: 0 }}
                            className="text-6xl font-bold font-mono tracking-tight"
                         >
                            {finalQuotation.toFixed(2)}
                         </motion.span>
                       </AnimatePresence>
                    </div>
                    
                    <div className="mt-8 grid grid-cols-2 gap-4 border-t border-white/10 pt-6">
                      <div className="text-left">
                        <span className="block text-slate-400 text-xs mb-1">未折扣价格</span>
                        <span className="font-mono text-lg text-slate-300">¥{priceWithProfit.toFixed(2)}</span>
                      </div>
                       <div className="text-right">
                        <span className="block text-slate-400 text-xs mb-1">净利润预估</span>
                        <span className="font-mono text-lg text-emerald-400 font-medium">
                          ¥{((priceWithProfit - totalCost) - (priceWithProfit * (discountRate/100))).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>

          </div>
        </div>

        {/* 底部操作区和历史记录 */}
        <motion.div 
           initial={{ opacity: 0, y: 20 }} 
           animate={{ opacity: 1, y: 0 }} 
           transition={{ duration: 0.5, delay: 0.3 }}
           className="mt-10 space-y-8 print:hidden"
        >
          <Separator className="bg-slate-200" />
          
          {/* 操作按钮组 */}
          <div className="flex flex-wrap justify-center gap-4">
             <Button 
               variant="outline" 
               size="lg" 
               className="border-slate-300 text-slate-700 hover:bg-slate-50 min-w-[120px]"
               onClick={handleReset}
             >
               <RotateCcw className="mr-2 size-4" />
               重置
             </Button>
             <Button 
               variant="outline" 
               size="lg" 
               className="border-slate-300 text-slate-700 hover:bg-slate-50 min-w-[120px]"
               onClick={handlePrint}
             >
               <Printer className="mr-2 size-4" />
               打印
             </Button>
             <Button 
               variant="secondary" 
               size="lg" 
               className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 min-w-[140px]"
               onClick={handleSave}
             >
               <Save className="mr-2 size-4" />
               保存报价
             </Button>
             <Button 
               size="lg" 
               className="bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-200 min-w-[140px]"
               onClick={handleSubmit}
             >
               <Send className="mr-2 size-4" />
               提交报价
             </Button>
          </div>

          {/* 历史记录部分 */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
             <div className="flex items-center gap-2 mb-4">
                <History className="size-5 text-slate-500" />
                <h3 className="text-lg font-bold text-slate-800">历史报价记录</h3>
             </div>
             
             {history.length === 0 ? (
               <div className="flex flex-col items-center justify-center py-10 text-slate-400 bg-slate-50 rounded-lg border border-dashed border-slate-200">
                  <Clock className="size-10 mb-2 opacity-20" />
                  <p>暂无历史记录，请保存或提交新的报价</p>
               </div>
             ) : (
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                 {history.map((record) => (
                   <div 
                     key={record.id} 
                     className="bg-slate-50 hover:bg-blue-50/50 border border-slate-200 hover:border-blue-200 rounded-lg p-4 cursor-pointer transition-all active:scale-[0.98] group"
                     onClick={() => loadHistoryItem(record)}
                   >
                     <div className="flex justify-between items-start mb-2">
                       <div>
                         <h4 className="font-semibold text-slate-900 line-clamp-1">{record.productName || '未命名产品'}</h4>
                         <p className="text-xs text-slate-500 flex items-center mt-1">
                           <Calendar className="size-3 mr-1" />
                           {new Date(record.timestamp).toLocaleString()}
                         </p>
                       </div>
                       <Badge variant="secondary" className={`text-xs ${record.status === 'submitted' ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-700'}`}>
                         {record.status === 'submitted' ? '已提交' : '已保存'}
                       </Badge>
                     </div>
                     <Separator className="my-2" />
                     <div className="flex justify-between items-end">
                       <div className="text-xs text-slate-500">
                         {record.bladeDiameter} x {record.bladeLength} mm
                       </div>
                       <div className="text-right">
                         <span className="text-xs text-slate-400 block">最终报价</span>
                         <span className="font-bold text-blue-600 font-mono">¥{record.finalPrice.toFixed(2)}</span>
                       </div>
                     </div>
                   </div>
                 ))}
               </div>
             )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
